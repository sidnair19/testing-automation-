from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Path to your ChromeDriver
chromedriver_path = '/path/to/chromedriver'

# Initialize the WebDriver outside the try block
driver = webdriver.Chrome()

try:
    # 1. Open the homepage
    driver.get('https://www.freshtohome.com')
    print("Homepage opened successfully.")
    time.sleep(3)  # Wait for the page to load
    

    # 2. Search for a product (e.g., "fish")
    search_box = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.NAME, 'q'))
    )
    search_box.send_keys('fish')
    search_box.send_keys(Keys.RETURN)
    print("Search functionality tested successfully.")
    time.sleep(3)  # Wait for the search results to load

    product_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//a[@href='https://www.freshtohome.com/seer-fish-surmai-neymeen-large.html']"))
    )
    product_link.click()
    print("Clicked the specific product link.")
    time.sleep(3)  
    #add to cart......
    add_to_cart_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@type='button' and @data='https://www.freshtohome.com/seer-fish-surmai-neymeen-large-cube-280g-300g.html']"))
    )
    add_to_cart_button.click()
    print("Clicked the 'Add to Cart' button.")
    print("Product added to cart successfully.")
    time.sleep(30)  # Wait for the action to complete

finally:
    # Ensure the browser is closed
    driver.quit()