from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Path to the chromedriver executable
chromedriver_path = '/path/to/your/chromedriver'

# Set up Chrome options
chrome_options = Options()
chrome_options.add_argument("--start-maximized")  # Open the browser in maximized mode
chrome_options.add_argument("--disable-notifications")  # Disable notifications

# Initialize the Chrome driver
service = Service(chromedriver_path)
driver = webdriver.Chrome()

# Open the website
driver.get("https://www.freshtohome.com")

try:
    # Allow some time for the page to load
    time.sleep(5)
    
    # Close the overlay if it's present
    try:
        close_overlay = driver.find_element(By.CSS_SELECTOR, "div.jquery-modal.blocker")
        close_overlay.click()
        time.sleep(2)  # Allow some time for the overlay to close
    except:
        pass  # If overlay is not present, continue
    
    # Click the login icon to navigate to the login page
    
    # 6. Click the login icon to navigate to the login page
    login_icon = driver.find_element(By.CSS_SELECTOR, "a.profile-icon[title='Login']")
    driver.execute_script("arguments[0].click();", login_icon)
    print("Clicked the login icon.")
    time.sleep(3)  # Wait for the login page to load

    # 7. Enter the mobile number
    mobile_number_input = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "youama-phone"))  # Use the actual ID or name attribute of the mobile number input field
    )
    mobile_number_input.send_keys("7795940011")  # Replace with the actual mobile number

    # 8. Click the "Send OTP" button
    send_otp_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, "sendOtpBtn"))  # Use the actual ID of the "Send OTP" button
    )
    send_otp_button.click()
    print("Clicked the 'Send OTP' button.")
    time.sleep(15) 
    
    # 9. Click the "My Account" button
    my_account_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "a.profile-icon[title='My Account']"))
    )
    driver.execute_script("arguments[0].click();", my_account_button)
    print("Clicked the 'My Account' button.")
    time.sleep(10)
    
finally:
    # Close the browser
    driver.quit()