from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def enter_credentials(email, password):
    driver = webdriver.Chrome()
    
    try:
        driver.get('https://candymapper.com/')
        time.sleep(3)
        button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//a[@id="4"]'))
        )
        button.click()
        time.sleep(3)
        sign_in_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//a[@id="n-238369238407-membership-sign-in"]'))
        )
        sign_in_link.click()
        time.sleep(3)
        
        email_field = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, '//input[@name="email"]'))
        )
        email_field.send_keys(email)
        print("Email entered successfully.")

        password_field = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, '//input[@name="password"]'))
        )
        password_field.send_keys(password)
        print("Password entered successfully.")
    finally:
        driver.quit()

enter_credentials('chandan.tkgowda@gmail.com', 'Cktg2167')