from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def open_website_and_verify_heading():
    driver = webdriver.Chrome()
    
    try:
        driver.get('https://candymapper.com/')
        print("Website opened successfully.")
        time.sleep(3)
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, 'h1'))
        )

        heading_element = driver.find_element(By.TAG_NAME, 'h1')
        heading_text = heading_element.text
        print(f"Heading text is: {heading_text}")

        expected_text = "CandyMapper: The Website That Goes Wrong!"
        if heading_text == expected_text:
            print("Heading text verification passed.")
        else:
            print("Heading text verification failed.")
    finally:
        driver.quit()

open_website_and_verify_heading()