from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def click_sign_in_link():
    driver = webdriver.Chrome()
    
    try:
        driver.get('https://candymapper.com/')
        time.sleep(3)
        button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//a[@id="4"]'))
        )
        button.click()
        time.sleep(3)
        sign_in_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//a[@id="n-238369238407-membership-sign-in"]'))
        )
        sign_in_link.click()
        print("Sign In link clicked successfully.")
        time.sleep(3)
    finally:
        driver.quit()

click_sign_in_link()