from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import time



# Initialize the WebDriver
driver = webdriver.Chrome()

try:
    # 1. Open the specified URL
    driver.get('https://candymapper.com/')
    print("Website opened successfully.")
    time.sleep(3)  # Wait for the page to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.TAG_NAME, 'h1'))
    )
    
    # 3. Find the <h1> element and get its text
    heading_element = driver.find_element(By.TAG_NAME, 'h1')
    heading_text = heading_element.text
    print(f"Heading text is: {heading_text}")
    

    expected_text = "CandyMapper: The Website That Goes Wrong!"
    if heading_text == expected_text:
        print("Heading text verification passed.")
    else:
        print("Heading text verification failed.")
   
    # 2. Click on the button with the specified attributes
    button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, '//a[@id="4"]'))
    )
    button.click()
    print("Button clicked successfully.")
    time.sleep(3)  # Wait for the action to complete
    
    sign_in_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, '//a[@id="n-238369238407-membership-sign-in"]'))
    )
    sign_in_link.click()
    print("Sign In link clicked successfully.")
    time.sleep(3) 
    # 2. Enter the email
    email_field = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.XPATH, '//input[@name="email"]'))
    )
    email_field.send_keys('chandan.tkgowda@gmail.com')
    print("Email entered successfully.")
    
    # 3. Enter the password
    password_field = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.XPATH, '//input[@name="password"]'))
    )
    password_field.send_keys('Cktg2167')
    print("Password entered successfully.")
    
    # 4. Click the 'Sign in' button
    sign_in_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, '//button[@data-aid="MEMBERSHIP_SSO_SUBMIT"]'))
    )
    sign_in_button.click()
    print("Sign In button clicked successfully.")
    time.sleep(7)
    try:
        error_message = WebDriverWait(driver, 5).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, 'p[data-aid="MEMBERSHIP_SSO_ERR_REND"]'))
        )
        print("Invalid password or email address.")
    except:
        print("No error message found, login may have been successful.")
    
    #verifection of sucessfull login

    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.TAG_NAME, 'h2'))
    )
    
    # 3. Find the <h2> element and get its text
    heading_element = driver.find_element(By.TAG_NAME, 'h2')
    heading_text = heading_element.text
    print(f"Heading text is: {heading_text}")
    
    # 4. Verify the heading text
    expected_text = "Hello Chandan"  # Modify this as needed
    if expected_text in heading_text:
        print("login passed.")
    else:
        print("error in logging.")
finally:
    # Ensure the browser is closed
    driver.quit()