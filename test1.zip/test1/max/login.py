from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def test_search_functionality():
    driver = webdriver.Chrome()  # Initialize Chrome WebDriver
    driver.get("https://www.maxfashion.in/in/en/search?q=%3AallCategories%3Amaxwomen&price=99,799&range=99,3999&utm_source=google&utm_medium=pmax&utm_campaign=19964033759&adgroupid=&utm_content=&utm_term=&gad_source=1&gclid=CjwKCAjwhvi0BhA4EiwAX25uj8FC_7uUmub8Vx-Onvcqv13VfiYPyUB7SphLvSIdQDRE8xGSSdDtJRoC8G4QAvD_BwE")

    try:
        print("homepage entred !!!!")
        # Wait for the search input field to be visible
        search_input = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "js-site-search-input"))
        )
        print("search bar found ")
        # Clear any existing text in the search input field
        search_input.clear()
        
        # Enter "t-shirt" into the search input field
        search_input.send_keys("t-shirt")
        print("Input 't-shirt' into the search box")
        
        # Submit the search by pressing Enter
        search_input.send_keys(Keys.RETURN)
        print("Search submitted")
        
         # Wait for the button element to be clickable
        button_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//div[@id="product-1000013955216-Pink-PINK"]//button[@aria-label="fav-btn"]'))
        )

        # Click the button element
        button_element.click()
        print("product  clicked successfully")
        time.sleep(15)

    except Exception as e:
        print("Test failed!", e)

    finally:
        # Close the WebDriver session
        driver.quit()

if __name__ == "__main__":
    test_search_functionality()