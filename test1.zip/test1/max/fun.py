import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def click_size_and_add_to_basket():
    # Initialize Chrome WebDriver
    driver = webdriver.Chrome()

    try:
        # Open the specific product page on Max Fashion
        driver.get("https://www.maxfashion.in/in/en/SHOP-Max-Pink-URB-N-Men-Oversized-T-shirt-For-Men/p/1000013955216-Pink-PINK")

        # Wait for the size button element to be clickable
        size_button_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//div[@class="jss626"]/button[@data-code="1000013955217"]'))
        )

        # Click the size button element
        size_button_element.click()
        print("Size button clicked successfully")

        # Wait for a short duration to ensure the size is selected before proceeding
        time.sleep(2)

        # Wait for the "ADD TO BASKET" button to be clickable
        add_to_basket_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//div[@class="MuiBox-root jss3298"]/button[@class="MuiButtonBase-root MuiButton-root MuiButton-contained jss3299 MuiButton-containedPrimary"]'))
        )

        # Click the "ADD TO BASKET" button
        add_to_basket_button.click()
        print("ADD TO BASKET button clicked successfully")

        # Wait for a short duration to ensure the action is completed before closing
        time.sleep(5)


    finally:
        # Close the browser
        driver.quit()

if __name__ == "__main__":
    click_size_and_add_to_basket()