from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import time

# Set up the Chrome WebDriver
driver = webdriver.Chrome()

try:
    # Open the SauceDemo website
    driver.get('https://www.saucedemo.com/')

    # Wait for the page to load completely
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, 'user-name'))
    )
    print('Page loaded successfully')

    # Locate the username input field
    username_input = driver.find_element(By.ID, 'user-name')
    time.sleep(3)
    # Locate the password input field
    password_input = driver.find_element(By.ID, 'password')
    time.sleep(3)
    # Enter the username
    username_input.send_keys('standard_')
    print('Username entered successfully')

    # Enter an invalid password
    password_input.send_keys('invalid_password')
    print('Invalid password entered')
    time.sleep(6)
    # Locate the login button and click it
    login_button = driver.find_element(By.ID, 'login-button')
    login_button.click()
    print('Login button clicked')

    # Wait for the error message to appear
    error_message = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, "//h3[@data-test='error']"))
    )
    print('Error message appeared: ', error_message.text)
    
    
finally:
    # Close the browser
    driver.quit()