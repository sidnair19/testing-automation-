import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


# Set up the Chrome WebDriver
driver = webdriver.Chrome()

try:
    # Open the SauceDemo website and log in (if not already logged in)
    driver.get('https://www.saucedemo.com/')

    # Wait for the page to load completely
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, 'user-name'))
    )
    print('Page loaded successfully')

    # Locate the username input field
    username_input = driver.find_element(By.ID, 'user-name')
    time.sleep(3)
    # Locate the password input field
    password_input = driver.find_element(By.ID, 'password')
    time.sleep(3)
    # Enter the username
    username_input.send_keys('standard_user')
    print('Username entered successfully')

    # Enter the password
    password_input.send_keys('secret_sauce')
    print('Password entered successfully')
    time.sleep(3)
    # Locate the login button and click it
    login_button = driver.find_element(By.ID, 'login-button')
    login_button.click()
    print('Login button clicked')

    # Wait for the inventory page to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CLASS_NAME, 'inventory_list'))
    )
    print('Inventory page loaded successfully')
    time.sleep(3)
    # Locate the "Add to cart" button for the Sauce Labs Bolt T-Shirt and click it
    add_to_cart_button = driver.find_element(By.ID, 'add-to-cart-sauce-labs-bolt-t-shirt')
    add_to_cart_button.click()
    print('Add to cart button clicked')
    time.sleep(5)

    cart_icon = driver.find_element(By.CLASS_NAME, 'shopping_cart_link')
    cart_icon.click()

    # Wait for the cart page to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CLASS_NAME, 'cart_list'))
    )
    print("Cart page loaded successfully")
    time.sleep(8)
    remove_button = driver.find_element(By.ID, 'remove-sauce-labs-bolt-t-shirt')
    remove_button.click()
    print("Item removed from the cart successfully")
    print("product removed the cart")
    time.sleep(5)
finally:
    # Close the browser
    driver.quit()