from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

def nike_login(username, password):
    # Set up the WebDriver (assuming ChromeDriver)
    driver = webdriver.Chrome()
    driver.get("https://accounts.nike.com/lookup?client_id=4fd2d5e7db76e0f85a6bb56721bd51df&redirect_uri=https://www.nike.com/auth/login&response_type=code&scope=openid%20nike.digital%20profile%20email%20phone%20flow%20country&state=416b074c98f44cefac8c02a870165841&code_challenge=K3Up2AijQNtCQuWPyd-tJCmSAyCJnwU5T_XxJKJXFaE&code_challenge_method=S256")

    try:
        # Wait for the page to load
        time.sleep(3)

        # Find the username input field and enter username
        username_input = driver.find_element(By.ID, "username")
        username_input.clear()  # Clear existing input (if any)
        username_input.send_keys("Siddharthdileep2003@gmail.com")

        continue_button = driver.find_element(By.XPATH, "//button[@aria-label='continue']")
        # Verify the button is present
        assert continue_button.is_displayed()
        print("Continue button found!")
        # Click on the continue button
        continue_button.click()
        print("Clicked on Continue button")

        # Wait for the password page to load
        time.sleep(100)

        # Find the password input field and enter password
        password_input = driver.find_element(By.ID, "password")
        password_input.clear()  # Clear existing input (if any)
        password_input.send_keys("4g2DLggY/h9USfA")

        # Find and click the Sign In button
        sign_in_button = driver.find_element(By.XPATH, "//button[@aria-label='Sign In']")
        sign_in_button.click()

        # Wait for the login process to complete (adjust wait time as needed)
        time.sleep(5)

        # Optionally, add verification steps to ensure successful login
        current_url = driver.current_url
        if current_url.startswith("https://accounts.nike.com/challenge?client_id=4fd2d5e7db76e0f85a6bb56721bd51df&redirect_uri=https://www.nike.com/auth/login&response_type=code&scope=openid%20nike.digital%20profile%20email%20phone%20flow%20country&state=60cb8408d0754050837618d9296ca428&code_challenge=kuVH49jt2YIQS72AwpyLvK_uo5CSScdVnrxC9N3iVvs&code_challenge_method=S256"):
            print("Login successful!")
        else:
            print("Login failed. Current URL:", current_url)

    except Exception as e:
        print("Exception:", e)

    finally:
        # Close the browser session
        driver.quit()

# Replace with your Nike login credentials
username = "Siddharthdileep2003@gmail.com"
password = "4g2DLggY/h9USfA"

# Call the function with your credentials
nike_login(username, password)