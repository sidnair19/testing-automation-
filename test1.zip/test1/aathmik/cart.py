from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Initialize the Chrome WebDriver
driver = webdriver.Chrome()

try:
    # Open the website
    driver.get("https://magento.softwaretestingboard.com/")
    
    # Functionality 1: Log in
    login_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.LINK_TEXT, "Sign In"))
    )
    login_link.click()
    
    email_input = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "email"))
    )
    email_input.send_keys("aatmikx23@gmail.com")
    
    password_input = driver.find_element(By.ID, "pass")
    password_input.send_keys("aathmik@1234")
    
    login_button = driver.find_element(By.ID, "send2")
    login_button.click()
    print("password and email entered")
    # Wait for login to complete
    time.sleep(5)
    
    # Functionality 2: Search for a product
    search_box = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "search"))
    )
    print("sreach bar located")
    search_box.send_keys("bag")
    search_box.send_keys(Keys.ENTER)
    print("key passed ")
    # Wait for search results to load
    time.sleep(6)
    # Wait for the product image container to be present
    product_image_container = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, "//span[@class='product-image-container']"))
    )

    # Click on the product image container to navigate to the product page
    product_image_container.click()


    add_to_cart_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, "product-addtocart-button"))
    )
    add_to_cart_button.click()

    # Optionally, wait for some indication that the item was added to the cart (e.g., a confirmation message)
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "div.message-success"))
    )
    time.sleep(10)
    print("Product added to cart successfully.")


finally:
    # Close the browser
    driver.quit()