import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Initialize Chrome WebDriver (you can use other WebDriver as needed)
driver = webdriver.Chrome()

try:
    # Open the webpage where the label and radio button are located
    driver.get("https://www.nike.com/in/t/air-max-90-shoes-GQrz8k/HF3835-100")  # Replace with your actual URL
    
    # Locate the label by its text
    label_text = "UK 10"
    label_element = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, f"//label[text()='{label_text}']"))
    )
    
       # Wait for the button to be clickable
    view_details_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//button[contains(@class, 'readMoreBtn')]"))
    )
    
    # Click the "View Product Details" button
    view_details_button.click()
   
   
    
    time.sleep(15)


finally:
    # Close the WebDriver session
    driver.quit()