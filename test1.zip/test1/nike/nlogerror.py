import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# Set up the WebDriver (make sure the path to chromedriver is correct)
driver = webdriver.Chrome()

# Open the Nike login page
driver.get("https://accounts.nike.com/lookup?client_id=4fd2d5e7db76e0f85a6bb56721bd51df&redirect_uri=https://www.nike.com/auth/login&response_type=code&scope=openid%20nike.digital%20profile%20email%20phone%20flow%20country&state=8c3041dcde364c0a8e2c85225364b345&code_challenge=cO2RQmrhHzzMfUO0Ve-32SmARMESTHruKj2CvlJNhLg&code_challenge_method=S256")

try:
    # Wait for the email input to be present
    email_input = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "username"))
    )
    email_input.click()

    # Enter the email address
    email_input.send_keys("Siddharthdileep2003@gmail.com")

    # Find and click the "Continue" button
    continue_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Continue')]"))
    )
    continue_button.click()

    time.sleep(10)
    # Wait for the password page to load
    password_input = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "input[name='password']"))
    )

    # Enter password (optional, if you need to continue automating the login process)
    password_input.send_keys("4g2DLggY/h9USfA")

    # Submit the password form
    password_input.send_keys(Keys.RETURN)

    # Add additional steps if necessary

except TimeoutException:
    print("Element not found or page took too long to load")
finally:
    # Close the driver
    driver.quit()