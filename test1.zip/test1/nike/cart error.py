import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, ElementClickInterceptedException

# Initialize Chrome WebDriver (replace with your path if needed)
driver = webdriver.Chrome()

try:
    # Open the Nike website
    driver.get("https://www.nike.com/in/t/air-max-dn-se-shoes-MZ6hPZ/HM0810-401")

    
    # Wait for the page to load and locate the size option
    size_option = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//label[contains(text(), 'UK 10')]"))
    )
    size_option.click()
    print("Size option selected")
    time.sleep(4)
    # Wait for the "View Product Details" button to be clickable
    view_details_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//button[contains(@class, 'readMoreBtn') or contains(text(), 'View Product Details')]"))
    )

   
   # Wait for the "Add to Bag" button to be clickable
    add_to_bag_button = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.XPATH, "//button[@aria-label='Add to Bag' and @data-testid='atb-button']"))
    )
    
    # Scroll to the "Add to Bag" button using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", add_to_bag_button)
    driver.execute_script("arguments[0].click();", add_to_bag_button)
    time.sleep(30)
    print("Add to Bag button clicked")
     # Wait for the "View Bag" button to be clickable
    view_bag_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@data-automation-id='error-view-cart' and contains(text(), 'View Bag')]"))
    )
    
    # Click the "View Bag" button
    view_bag_button.click()
    print("View Bag button clicked")  

   
            

except (TimeoutException, NoSuchElementException, ElementClickInterceptedException) as e:
    print("Error encountered:", e)
finally:
    # Close the WebDriver session
    driver.quit()
