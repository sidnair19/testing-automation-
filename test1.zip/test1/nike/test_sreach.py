import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Initialize Chrome WebDriver (you can use other WebDriver as needed)
driver = webdriver.Chrome()

try:
    # Open the website
    driver.get("https://www.nike.com/")

    # Wait for the search icon to be clickable
    search_icon = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, "nav-search-icon"))
    )
    
    # Click the search icon
    search_icon.click()
    print("sreach bar verified")
    
    # Locate the search input field and wait for it to be visible
    search_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "gn-search-input"))
    )
    
    # Clear any existing text in the search input field
    search_input.clear()
    search_input.send_keys("air max")
    search_input.send_keys(Keys.RETURN)
    print("input key passed sucesfully")
   
    # Wait until the search results container is visible
    search_results = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CLASS_NAME, "search-results-link-container"))
    )
    
    # Get the inner HTML of the search results container
    search_results_html = search_results.get_attribute('innerHTML')

    
    

finally:
    # Close the WebDriver session
    driver.quit()