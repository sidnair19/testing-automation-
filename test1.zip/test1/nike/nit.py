import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def test_homepage_and_product():
    driver = webdriver.Chrome()
    driver.get("https://www.nike.com/in/")

    try:
        # Check if the homepage title is correct
        assert "Nike. Just Do It" in driver.title
        print("The title is verified!")

        # Check if the search button is present
        search_button = driver.find_element(By.ID, "nav-search-icon")
        assert search_button.is_displayed()
        print("Search button found!")
        
        # Verify the bag icon is present
        bag_icon = driver.find_element(By.XPATH, "//a[@aria-label='Bag Items: 0']")
        assert bag_icon.is_displayed()
        print("Bag icon found!")

        # Proceed with the product search and interaction
        # Wait for the search icon to be clickable
        search_icon = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, "nav-search-icon"))
        )
        search_icon.click()
        print("Search bar verified")

        # Locate the search input field and wait for it to be visible
        search_input = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.ID, "gn-search-input"))
        )
        search_input.clear()
        search_input.send_keys("nike air max")
        search_input.send_keys(Keys.RETURN)
        print("Input key passed successfully")

        # Wait for the product link with the specific href attribute to be clickable
        product_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "a.product-card__link-overlay[href*='air-max-dn-se-shoes']"))
        )
        
        # Scroll the product link into view using JavaScript
        driver.execute_script("arguments[0].scrollIntoView(true);", product_link)
        
        # Click the product link using JavaScript to avoid interception
        driver.execute_script("arguments[0].click();", product_link)
        print("Product link clicked")

        # Wait for the page to load and locate the size option
        size_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//label[contains(text(), 'UK 10')]"))
        )
        size_option.click()
        print("Size option selected")

        # Wait for the "View Product Details" button to be clickable
        view_details_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(@class, 'readMoreBtn') or contains(text(), 'View Product Details')]"))
        )
        
        # Click the "View Product Details" button
        view_details_button.click()
        print("View Product Details button clicked")

        # Adding a sleep to ensure actions complete before closing
        time.sleep(15)

        print("Homepage and product interaction tests passed!")

    except AssertionError as e:
        print("Test failed!", e)

    finally:
        # Close the WebDriver session
        driver.quit()

if __name__ == "__main__":
    test_homepage_and_product()