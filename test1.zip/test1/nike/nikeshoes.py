import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Initialize Chrome WebDriver
driver = webdriver.Chrome()

try:
    # Open the Nike website
    driver.get("https://www.nike.com/")

    # Wait for the search icon to be clickable
    search_icon = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.ID, "nav-search-icon"))
    )
    
    # Click the search icon
    search_icon.click()
    print("Search bar verified")
    
    # Locate the search input field and wait for it to be visible
    search_input = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "gn-search-input"))
    )
    
    # Clear any existing text in the search input field
    search_input.clear()
    search_input.send_keys("nike air max")
    search_input.send_keys(Keys.RETURN)
    print("Input key passed successfully")
    
    # Wait for the product link with the specific href attribute to be clickable
    product_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "a.product-card__link-overlay[href*='air-max-dn-se-shoes']"))
    )
    
    # Scroll the product link into view using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", product_link)
    
    # Click the product link using JavaScript to avoid interception
    driver.execute_script("arguments[0].click();", product_link)
    print("Product link clicked")
    print("product page opened ...")
    # Wait for the page to load and locate the size option
    size_option = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//label[contains(text(), 'UK 10')]"))
    )
    time.sleep(5)
    size_option.click()
    print("Size option selected")

    # Wait for the "View Product Details" button to be clickable
    view_details_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//button[contains(@class, 'readMoreBtn') or contains(text(), 'View Product Details')]"))
    )
    next_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@data-testid='nextBtn']"))
    )

    # Click the "Next" button 5 times with a 3-second delay between each click
    for i in range(5):
        next_button.click()
        print(f"Next button clicked {i + 1} time(s)")
        time.sleep(3)  # Wait for 3 seconds before the next click

    # Adding a sleep to ensure actions complete before closing
    time.sleep(5)
    
    # Click the "View Product Details" button
    view_details_button.click()
    print("View Product Details button clicked")

    # Adding a sleep to ensure actions complete before closing
    time.sleep(5)
    
  # Wait for the "Close Modal" button to be clickable
    close_modal_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Close Modal' and @data-testid='modal-close-button']"))
    )
    
    # Click the "Close Modal" button
    close_modal_button.click()
    print("Close Modal button clicked")
    time.sleep(10)
finally:
    # Close the WebDriver session
    driver.quit()