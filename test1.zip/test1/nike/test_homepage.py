# test_homepage.py
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

def test_homepage():
    driver = webdriver.Chrome()
    driver.get("https://www.nike.com/in/")

    try:
        # Check if the homepage title is correct
        assert "Nike. Just Do It" in driver.title
        print("the title is verifed!!!!")

        # Check if the search bar is present
        # Locate the search button using its ID
        search_button = driver.find_element(By.ID, "nav-search-icon")

        # Verify the search button is present
        assert search_button.is_displayed()
        print("Search button found!")
         
        #Verify the bag icon is present
        bag_icon = driver.find_element(By.XPATH, "//a[@aria-label='Bag Items: 0']")
        assert bag_icon.is_displayed()
        print("Bag icon found!")
        
        print("Homepage test passed!")
        time.sleep(10)
    except AssertionError as e:
        print("Homepage test failed!", e)

    driver.quit()

if __name__ == "__main__":
    test_homepage()