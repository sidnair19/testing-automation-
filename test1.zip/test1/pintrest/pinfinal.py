from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Set up the Chrome WebDriver
driver = webdriver.Chrome()

try:
    # Step 1: Open the website and log in
    driver.get('https://in.pinterest.com/')

    # Wait for the page to load
    WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, '[data-test-id="simple-login-button"] button'))
    ).click()

    # Wait for the login fields to appear
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, 'email'))
    )

    # Enter the email address
    email_input = driver.find_element(By.ID, 'email')
    email_input.send_keys('krishihsudhakar@gmail.com')
    print('Email entered')

    # Enter the password
    password_input = driver.find_element(By.NAME, 'password')
    password_input.send_keys('kuki1234')
    print("Password entered")

    # Click the login button
    login_button = driver.find_element(By.XPATH, '//button[div/div/div[text()="Log in"]]')
    login_button.click()
    print("Login successful")

    # Wait for the next page to load
    time.sleep(15)

    # Step 2: Perform search after login
    driver.get("https://in.pinterest.com/today/")
    
    # Allow time for the page to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, 'input.form-field.form-field--input[aria-label="Search products"]'))
    )

    # Perform search
    search_box = driver.find_element(By.CSS_SELECTOR, 'input.form-field.form-field--input[aria-label="Search products"]')
    search_box.send_keys("iphone")
    search_box.send_keys(Keys.ENTER)
    print("Search term 'iphone' entered and search initiated")


    # Allow time for search results to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "div[data-test-id='pin']"))
    )

    # Check that search results are present
    results = driver.find_elements(By.CSS_SELECTOR, "div[data-test-id='pin']")
    assert len(results) > 0, "No search results found"

    # Locate the specific image by its src attribute and click on it
    image_element = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "img[src='https://i.pinimg.com/236x/e2/ec/51/e2ec51531a27aa359e7646ffda4910c8.jpg']"))
    )
    image_element.click()

    # Locate the "Save" button by its aria-label attribute and click on it
    save_button = WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "button[aria-label='Save']"))
    )
    save_button.click()
    print("Image saved successfully")

      # Locate the comment editor container
    comment_editor = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "div[data-test-id='comment-editor-container'] .public-DraftEditor-content"))
    )

    # Click to activate the comment editor by sending a space key
    comment_editor.send_keys(Keys.SPACE)

    # Add the comment text
    comment_editor.send_keys("This is very good")
    print("Comment added")

   # Click the "Post" button to submit the comment
    post_button = WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "button[aria-label='Post']"))
    )
    post_button.click()
    print("Comment submitted")

    # Allow time for any additional actions to complete
    time.sleep(20)

finally:
    # Close the browser
    driver.quit()