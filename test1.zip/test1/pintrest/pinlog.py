from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
import time

# Set up the Chrome WebDriver
driver = webdriver.Chrome()

try:
    # Open the website
    driver.get('https://in.pinterest.com/')

    # Wait for the page to load
    time.sleep(3)  # Use WebDriverWait for more reliable waiting

    # Click the "Log in" button
    login_button = driver.find_element(By.CSS_SELECTOR, '[data-test-id="simple-login-button"] button')
    login_button.click()

    # Wait for the login fields to appear
    time.sleep(3)

    email_input = driver.find_element(By.ID, 'email')
    email_input.click()

    # Enter the email address
    email_input.send_keys('krishihsudhakar@gmail.com')
    print('the email entered')
    # Enter the password
    password_input = driver.find_element(By.NAME, 'password')  # Adjust the locator based on the actual input field
    password_input.send_keys('kuki1234')
    print("password enterd")

    login_button = driver.find_element(By.XPATH, '//button[div/div/div[text()="Log in"]]')
    login_button.click()
    print("login sucessfull")

    # Wait for the next page to load
    time.sleep(15)

finally:
    # Close the browser
    driver.quit()