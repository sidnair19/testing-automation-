from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Initialize the Chrome driver
driver = webdriver.Chrome()

try:
    # Step 1: Navigate to Pinterest homepage and perform search
    driver.get("https://in.pinterest.com/today/")
    
    # Allow time for the page to load
    time.sleep(5)
    
    # Perform search
    search_box = driver.find_element(By.NAME, "searchBoxInput")
    search_box.send_keys("rain")
    search_box.send_keys(Keys.ENTER)
    
    # Allow time for search results to load
    time.sleep(5)
    
    # Check that search results are present
    results = driver.find_elements(By.CSS_SELECTOR, "div[data-test-id='pin']")
    assert len(results) > 0, "No search results found"
    
    # Locate the specific image by its src attribute and click on it
    image_element = driver.find_element(By.CSS_SELECTOR, "img[src='https://i.pinimg.com/236x/e2/ec/51/e2ec51531a27aa359e7646ffda4910c8.jpg']")
    image_element.click()
    
    # Allow time for the image detail page to load
    time.sleep(5)
    
    # Step 2: Click on the "More options" button on the image detail page
    button_element = driver.find_element(By.CSS_SELECTOR, "button[aria-label='more']")
    button_element.click()
    
    # Allow time for the options menu to appear
    time.sleep(2)
    
    # Locate the "Save" button by its data-test-id attribute and click on it
    save_button = driver.find_element(By.CSS_SELECTOR, "div[data-test-id='standard-save-button']")
    save_button.click()
    print("image saved sucessfully")
    # Allow time for any additional actions to complete
    time.sleep(5)
    
    
finally:
    # Close the driver
    driver.quit()